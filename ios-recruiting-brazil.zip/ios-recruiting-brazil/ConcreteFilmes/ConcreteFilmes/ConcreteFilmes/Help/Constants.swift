//
//  Constants.swift
//  ConcreteFilmes
//
//  Created by Luis Felipe Tapajos on 07/11/2020.
//  Copyright © 2020 Luis Felipe Tapajos. All rights reserved.
//

import Foundation

//Url da API
let API_URL = "https://api.themoviedb.org/3/movie/popular"
let API_KEY = "19c142359dcac1a4c93032617619cad3"
let API_URL_MOCK = API_URL + "?api_key=19c142359dcac1a4c93032617619cad3&language=PT-BR"
let API_URL_IMAGES = "https://image.tmdb.org/t/p/original"
let API_URL_Movies = "https://www.themoviedb.org/?language=en"
let API_URL_Generos = "https://api.themoviedb.org/3/genre/tv/list?api_key=19c142359dcac1a4c93032617619cad3&language=pt-BR"
